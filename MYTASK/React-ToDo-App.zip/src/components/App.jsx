import React, { Component } from 'react';
import ShoppingList from './ShoppingList.jsx';

class App extends Component{
    render() {
        return (
            <div>
                <ShoppingList/>
            </div>
        )
    }
}

export default App;


