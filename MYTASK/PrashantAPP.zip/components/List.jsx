import React, { Component } from 'react';
import ShoppingStore from '../store/ShoppingStore.jsx';
//import HandleAction from '../actions/HandleAction.jsx';

class List extends Component {
    constructor(props) {
        super(props)

        this.state = {
            list: this.props.initialvalue
        }

    }
    render() {
        
        var items = this.state.list.map(function(item){
             return <li key={item.id}>{item.name}</li>
        });
        return (
            <div>
                <h1>Item List</h1>
                {items}
            </div>
        )
    }
}

export default List;