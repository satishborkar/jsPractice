import React, { Component } from 'react';
import List from './List.jsx';
import AddListItem from './AddListItem.jsx';
import ShoppingStore from '../store/ShoppingStore.jsx';


class ShoppingList extends Component {
    constructor(props){
        super(props)
        
        //console.log();
        this.state = {
            items:ShoppingStore.getItemList()
        };
        this.getItem = this.getItem.bind(this);
    }
    getItem(){
        this.setState({item:this.state.items});
    }
    render() {
        
        return (
            <div className="container">
                <div className="row">
                    <div className="col-sm-6">
                        <List initialvalue = {this.state.items}/>
                    </div>
                    <div className="col-sm-6">

                        <AddListItem headerProp ="Hi..from Header" changeValue={this.getItem} />

                    </div>
                </div>
            </div>
        );
    }
}
export default ShoppingList;