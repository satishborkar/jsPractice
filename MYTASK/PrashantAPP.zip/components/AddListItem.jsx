import React, { Component, PropTypes } from 'react';
import ShoppingList from './ShoppingList.jsx';
import HandleAction from '../actions/HandleAction.jsx';

const styleRequired = {
    color: 'red'
}

class AddListItem extends Component {

    constructor(props) {
        super(props),
        this.state = {
            basic : 'basic data',
            single :'single',
        }
        
    }


    handleSubmitEvent(e) {
        //console.log(("%c Hi!... "), "background: #0140ca; color: #fff; padding:2px; font-size:18px; line-height:22px")
        e.preventDefault();

        const item = {
           id: Math.floor(Math.random() * 1000),
           // date: new Date(),
            name: this.refs.name.value.trim(),
            description: this.refs.description.value.trim(),
            quantity: this.refs.quantity.value,
        }
        HandleAction.addItem(item);
        this.props.changeValue();
    }

    render() {
        return (
            <div>
                <form onSubmit={this.handleSubmitEvent.bind(this)}>
                    <h3 className="page-header">Add New Item</h3>

                    <div className="form-group">
                        <label htmlFor="listItemName">Name <span style={styleRequired}>*</span></label>
                        <input type="text" className="form-control" id="listItemName" placeholder="Enter name" required="required" ref="name" />
                    </div>

                    <div className="form-group">
                        <label htmlFor="listItemDescription">Description</label>
                        <textarea className="form-control" rows="3" id="listItemDescription" placeholder="Enter description" ref="description"></textarea>
                    </div>

                    <div className="form-group">
                        <label htmlFor="listItemQuantity">Quantity <span style={styleRequired}>*</span></label>
                        <div className="row">
                            <div className="col-xs-5 col-sm-6 col-md-4">
                                <input type="number" min="1" max="9999" step="1" defaultValue="1" className="form-control" id="listItemQuantity" required="required" ref="quantity" />
                            </div>
                        </div>
                    </div>

                    <hr />

                    <button type="submit" className="btn btn-primary">Add to list</button>
                    <button type="reset" className="btn btn-link">Cancel</button>
                </form>
            </div>
        )
    }
}

export default AddListItem;