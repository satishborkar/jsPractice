import constants from '../common/constants.js'
import Dispatcher from '../dispatcher/dispatcher.jsx';
import { EventEmitter } from 'events';

class ShoppingStore extends EventEmitter{
    constructor(){
        super();
        this.shoppingList = [];
    }
    setItemList(item){
        this.shoppingList.push(item);
        this.emit('change');
    }
    getItemList(){
        return this.shoppingList = [
            {   id:Math.floor(Math.random() * 1000),
                name:'satish',
                description:'XYZ',
                quantity:2
            },
            {
                id:Math.floor(Math.random() * 1000),
                name:'Bhim',
                description:'Description of BHim',
                quantity:2
            }
        ];
    }
    handleAction(payload){
        const action = payload;
        
        switch(action.type){
            case constants.ADD_ITEM:
            this.setItemList(action.item);            
            break;
            case constants.GET_ITEM:
            this.getItemList();            
            break;
        }
    }
}

var shoppingStore = new ShoppingStore;

//dispatcherIndex: AppDispatcher.register(paynowStore.handlerAction.bind(paynowStore));

ShoppingStore.dispatchToken = Dispatcher.register(shoppingStore.handleAction.bind(shoppingStore));


module.exports = shoppingStore;