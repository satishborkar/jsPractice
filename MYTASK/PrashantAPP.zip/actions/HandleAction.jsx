import Dispatcher from '../dispatcher/dispatcher.jsx';
import constant from '../common/constants.js';

class HandleAction{
    addItem(item){
        // console.log(item)
        
        var action = {
            type: constant.ADD_ITEM,
            item: item
          };
          Dispatcher.dispatch(action);
       
    }
    getItemList(){
        var action = {
            type: constant.GET_ITEM,
          };
          Dispatcher.dispatch(action);
          
    }
}

export default new HandleAction;

// function addItem(item){
//     console.log(item)
// }
// function getItemList(){
//     console.log(List)
// }
// module.exports = {addItem, getItemList};