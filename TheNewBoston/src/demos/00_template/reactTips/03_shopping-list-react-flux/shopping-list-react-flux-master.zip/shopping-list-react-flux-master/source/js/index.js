var React = require('react');
var ReactDOM = require('react-dom');
var ShoppingList = require('./components/ShoppingList');

ReactDOM.render(<ShoppingList />, document.querySelector('[data-react-application]'));