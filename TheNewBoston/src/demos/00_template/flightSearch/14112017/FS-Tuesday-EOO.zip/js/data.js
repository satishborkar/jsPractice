var data = (function() {
    var routes = [{
            "uid": "01",
            "name": "AI-202",
            "logo": "images/airIndia.jpg",
            "source": "Mumbai",
            "destination": "Pune",
            "sourcecode": "CST[BOM]",
            "destinationcode": "PNQ",
            "depart": "09:25",
            "arrive": "11:05",
            "price": "3500"
        },
        {
            "uid": "02",
            "name": "AF-258",
            "logo": "images/air-france.png",
            "source": "Pune",
            "destination": "Mumbai",
            "sourcecode": "PNQ",
            "destinationcode": "CST[BOM]",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "4300"
        },
        {
            "uid": "03",
            "name": "SJ-120",
            "logo": "images/spicejet.jpg",
            "source": "Pune",
            "destination": "Mumbai",
            "sourcecode": "PNQ",
            "destinationcode": "CST[BOM]",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "4800"
        },
        {
            "uid": "04",
            "name": "JA-458",
            "logo": "images/jetAirways.png",
            "source": "Mumbai",
            "destination": "Pune",
            "sourcecode": " CST[BOM] ",
            "destinationcode": " PNQ ",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "3800"
        },
        {
            "uid": "05",
            "name": "EA-987",
            "logo": "images/emirates.jpg",
            "source": "Pune",
            "destination": "Mumbai",
            "sourcecode": "PNQ",
            "destinationcode": "CST[BOM]",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "5200"
        },
        {
            "uid": "06",
            "name": "KLM-458",
            "logo": "images/klm.png",
            "source": "Mumbai",
            "destination": "Pune",
            "sourcecode": "CST[BOM]",
            "destinationcode": " PNQ ",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "6700"
        }
    ];
    return {
        routes: routes
    }
})();