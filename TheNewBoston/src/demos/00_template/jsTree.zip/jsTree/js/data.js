var jsCollection = {
    "data": [{
            "JavaScript": {
                "DataTypes": [{
                    "Primitive": [{
                            "String": {
                                "Properties": [{
                                    "name": "constructor",
                                    "desc": "Returns the string's constructor function"
                                }, {
                                    "name": "length",
                                    "desc": "Returns the length of a string"
                                }, {
                                    "name": "prototype",
                                    "desc": "Allows you to add properties and methods to an string object"
                                }],
                                "Methods": [{
                                        "name": "charAt()",
                                        "desc": "Returns the character at the specified index (position)"
                                    }, {
                                        "name": "charCodeAt()",
                                        "desc": "Returns the Unicode of the character at the specified index"
                                    }, {
                                        "name": "concat()",
                                        "desc": "Joins two or more strings, and returns a new joined strings"
                                    }, {
                                        "name": "endsWith()",
                                        "desc": "Checks whether a string ends with specified string/characters"
                                    },

                                    {
                                        "name": "fromCharCode()",
                                        "desc": "Converts Unicode values to characters"
                                    },
                                    {
                                        "name": "includes()",
                                        "desc": "Checks whether a string contains the specified string/characters"
                                    },
                                    {
                                        "name": "indexOf()",
                                        "desc": "Returns the position of the first found occurrence of a specified value in a string"
                                    },
                                    {
                                        "name": "lastIndexOf()",
                                        "desc": "Returns the position of the last found occurrence of a specified value in a string"
                                    },
                                    {
                                        "name": "localeCompare()",
                                        "desc": "Compares two strings in the current locale"
                                    },
                                    {
                                        "name": "match()",
                                        "desc": "Searches a string for a match against a regular expression, and returns the matches"
                                    },
                                    {
                                        "name": "repeat()",
                                        "desc": "Returns a new string with a specified number of copies of an existing string"
                                    },
                                    {
                                        "name": "replace()",
                                        "desc": "Searches a string for a specified value, or a regular expression, and returns a new string where the specified values are replaced"
                                    },
                                    {
                                        "name": "search()",
                                        "desc": "Searches a string for a specified value, or regular expression, and returns the position of the match"
                                    },
                                    {
                                        "name": "slice()",
                                        "desc": "Extracts a part of a string and returns a new string"
                                    },
                                    {
                                        "name": "split()",
                                        "desc": "Splits a string into an array of substrings"
                                    },
                                    {
                                        "name": "startsWith()",
                                        "desc": "Checks whether a string begins with specified characters"
                                    },
                                    {
                                        "name": "substr()",
                                        "desc": "Extracts the characters from a string, beginning at a specified start position, and through the specified number of character"
                                    },
                                    {
                                        "name": "substring()",
                                        "desc": "Extracts the characters from a string, between two specified indices"
                                    },
                                    {
                                        "name": "toLocaleLowerCase()",
                                        "desc": "Converts a string to lowercase letters, according to the host's locale"
                                    },
                                    {
                                        "name": "toLocaleUpperCase()",
                                        "desc": "Converts a string to uppercase letters, according to the host's locale"
                                    },
                                    {
                                        "name": "toLowerCase()",
                                        "desc": "Converts a string to lowercase letters"
                                    },
                                    {
                                        "name": "toString()",
                                        "desc": "Returns the value of a String object"
                                    },
                                    {
                                        "name": "toUpperCase()",
                                        "desc": "Converts a string to uppercase letters"
                                    },
                                    {
                                        "name": "trim()",
                                        "desc": "Removes whitespace from both ends of a string"
                                    },
                                    {
                                        "name": "valueOf()",
                                        "desc": "Returns the primitive value of a String object"
                                    }
                                ]
                            }
                        },
                        "Numbers",
                        "Boolean",
                        "Null",
                        "Undefined",
                        "Symbols"
                    ]
                }, {
                    "Complex": [{
                            "Object": [{
                                    "Object Constructor": [{
                                            "Properties": [
                                                "x"
                                                // { "name": "Object.length", "desc": "Has a value of 1" },
                                                // { "name": "Object.prototype", "desc": "Allows the addition of properties to all objects of type Object." }
                                            ]
                                        },
                                        "Methods"
                                    ]
                                },
                                "MATH",
                                "DATE",
                                "RegExp",
                                "Error"
                            ]
                        },
                        "Array",
                        "Function"
                    ]
                }]
            }
        },
        "Browser BOM",
        "DOM"
    ]
}