var app = document.getElementById("app");

var htmlString = '';
var level = 1;

function interateArray(data) {
    if (Array.isArray(data) && data.constructor.toString().indexOf("Array") > -1) {

        htmlString += '<ol class="' + 'type-' + level + '">';

        for (let i = 0; i < data.length; i++) {

            if (typeof data[i] == 'object' && data[i].constructor.toString().indexOf("Object") > -1) {
                if (data[i].hasOwnProperty('name')) {
                    displayDataList(data[i])
                } else {
                    htmlString += '<li>';
                    iterateObjectData(data[i]);
                    htmlString += '</li>';
                }
            } else {
                htmlString += '<li>';
                htmlString += wrapInHref(data[i]);
                htmlString += '</li>';
            }

        }
        htmlString += '</ol>';

        app.innerHTML = htmlString;

    }
};

function iterateObjectData(data) {

    level = level + 1;

    htmlString += '<ul class="' + 'type-' + level + '">';
    for (key in data) {
        htmlString += '<li>';

        if (typeof data[key] != 'string') {
            htmlString += wrapInHref(key);
        }

        // if (typeof data[key] == 'string') {
        //     htmlString += key + " : " + data[key];
        // }

        if (typeof data[key] == 'object' && data[key].constructor.toString().indexOf("Object") > -1) {
            iterateObjectData(data[key]);
        }

        if (Array.isArray(data[key])) {
            interateArray(data[key]);
        }
        htmlString += '</li>';
    }
    htmlString += '</ul>';
};

function displayDataList(obj) {
    htmlString += "<dl>";
    for (key in obj) {
        if (obj.hasOwnProperty(key)) {
            if (key == 'name') {
                htmlString += "<dt>";
                htmlString += obj[key];
                htmlString += "</dt>";
            } else {
                htmlString += "<dd>";
                htmlString += obj[key];
                htmlString += "</dd>";
            }

        }
    }
    htmlString += "</dl>";
};

function wrapInHref(textString, cssClass) {
    var text = '';
    if (cssClass) {
        text = '<a href="javascript:void(0)" onClick="toogle(this)" class="' + cssClass + '">' + textString + '</a>';
    } else {
        text = '<a href="javascript:void(0)" onClick="toogle(this)">' + textString + '</a>';
    }
    return text;
};



function toogle(elem) {
    if (elem.nextElementSibling != null &&
        elem.nextElementSibling.hasAttribute('style') &&
        elem.nextElementSibling.style.display == 'block') {
        elem.nextElementSibling.style.display = 'none';
    } else if (elem.nextElementSibling == null) {
        alert("Sorry!, there is no data availabe for this item");
    } else {
        elem.nextElementSibling.style.display = 'block';
    }
}

interateArray(jsCollection.data);