var data = (function() {
    var routes = [{
            "uid": "01",
            "name": "AI-202",
            "logo": "images/airIndia.jpg",
            "source": "Mumbai",
            "destination": "Pune",
            "sourcecode": "CST[BOM]",
            "destinationcode": "PNQ",
            "depart": "09:25",
            "arrive": "11:05",
            "price": "2500"
        },
        {
            "uid": "11",
            "name": "AF-258",
            "logo": "images/air-france.png",
            "source": "Pune",
            "destination": "Mumbai",
            "sourcecode": "PNQ",
            "destinationcode": "CST[BOM]",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "2500"
        },
        {
            "uid": "02",
            "name": "SJ-120",
            "logo": "images/spicejet.jpg",
            "source": "Pune",
            "destination": "Mumbai",
            "sourcecode": "PNQ",
            "destinationcode": "CST[BOM]",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "4500"
        },
        {
            "uid": "03",
            "name": "JA-458",
            "logo": "images/jetAirways.png",
            "source": "Mumbai",
            "destination": "Pune",
            "sourcecode": " CST[BOM] ",
            "destinationcode": " PNQ ",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "3800"
        },
        {
            "uid": "04",
            "name": "EA-987",
            "logo": "images/emirates.jpg",
            "source": "Pune",
            "destination": "Mumbai",
            "sourcecode": "PNQ",
            "destinationcode": "CST[BOM]",
            "depart": "10:00",
            "arrive": "12:05",
            "price": "3400"
        }

        // {
        //     "uid": "05",
        //     "name": "AF-453",
        //     "logo": "images/air-france.png",
        //     "source": "Dehli",
        //     "destination": "Chennai",
        //     "time": "08",
        //     "price": "5500"
        // },
        // {
        //     "uid": "12",
        //     "name": "EA-875",
        //     "logo": "images/emirates.jpg",
        //     "source": "Chennai",
        //     "destination": "Dehli",
        //     "time": "08",
        //     "price": "5800"
        // },
        // {
        //     "uid": "06",
        //     "name": "KLM-267",
        //     "logo": "images/klm.png",
        //     "source": "Chennai",
        //     "destination": "Dehli",
        //     "time": "22",
        //     "price": "5800"
        // },
        // {
        //     "uid": "07",
        //     "name": "BA-564",
        //     "logo": "images/british_airways_logo.png",
        //     "source": "Nagpur",
        //     "destination": "Chennai",
        //     "time": "08",
        //     "price": "2500"
        // },
        // {
        //     "uid": "08",
        //     "name": "VA-876",
        //     "logo": "images/virgin-Atlantic.png",
        //     "source": "Chennai",
        //     "destination": "Nagpur",
        //     "time": "22",
        //     "price": "3200"
        // },
        // {
        //     "uid": "13",
        //     "name": "BA-534",
        //     "logo": "images/british_airways_logo.png",
        //     "source": "Dehli",
        //     "destination": "Chennai",
        //     "time": "08",
        //     "price": "5800"
        // },
        // {
        //     "uid": "09",
        //     "name": "TA-765",
        //     "logo": "images/turkish_airlines_logo.png",
        //     "source": "Chennai",
        //     "destination": "Dehli",
        //     "time": "22",
        //     "price": "8500"
        // },
        // {
        //     "uid": "10",
        //     "name": "VA-098",
        //     "logo": "images/virgin-Atlantic.png",
        //     "source": "Nagpur",
        //     "destination": "Chennai",
        //     "time": "22",
        //     "price": "3200"
        // },
        // {
        //     "uid": "13",
        //     "name": "AI-204",
        //     "logo": "images/airIndia.jpg",
        //     "source": "Nagpur",
        //     "destination": "Pune",
        //     "time": "11:25",
        //     "price": "2500"
        // },
        // {
        //     "uid": "13",
        //     "name": "SJ-654",
        //     "logo": "images/spicejet.jpg",
        //     "source": "Pune",
        //     "destination": "Nagpur",
        //     "time": "11:25",
        //     "price": "2500"
        // },
        // {
        //     "uid": "14",
        //     "name": "JA-650",
        //     "logo": "images/jetAirways.png",
        //     "source": "Hydrabad",
        //     "destination": "Pune",
        //     "time": "14:10",
        //     "price": "3800"
        // },
        // {
        //     "uid": "15",
        //     "name": "TA-534",
        //     "logo": "images/turkish_airlines_logo.png",
        //     "source": "Pune",
        //     "destination": "Hydrabad",
        //     "time": "14:10",
        //     "price": "3800"
        // },
        // {
        //     "uid": "16",
        //     "name": "KLM-854",
        //     "logo": "images/klm.png",
        //     "source": "Mumbai",
        //     "destination": "Nagpur",
        //     "time": "14:10",
        //     "price": "3800"
        // }

    ];
    return {
        routes: routes
    }
})();