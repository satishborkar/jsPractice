#!/bin/bash

git add .
git commit -m "Update"
git push