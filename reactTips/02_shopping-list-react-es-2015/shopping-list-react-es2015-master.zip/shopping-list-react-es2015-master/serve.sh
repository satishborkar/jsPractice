#!/bin/bash

# To disable caching, use -c-1.
http-server -c-1 ./build