var React = require('react');

var EmptyList = function () {
  return (
    <div>
      There are no items in your list.
    </div>
  );
};

module.exports = EmptyList;