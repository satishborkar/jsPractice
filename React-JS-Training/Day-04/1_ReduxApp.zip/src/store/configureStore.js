// import { createStore } from "redux";
// import rootReducer from "../reducers";

// export default function configureStore(initialState) {
//     return createStore(rootReducer, initialState);
// }

// To Configure REDUX
// import { createStore, applyMiddleware } from "redux";
// import rootReducer from "../reducers";
// import thunk from "redux-thunk";

// export default function configureStore(initialState) {
//     return createStore(rootReducer, initialState, applyMiddleware(thunk) );
// }

//To Configure DevTools
import { createStore, applyMiddleware } from "redux";
import rootReducer from "../reducers";
import thunk from "redux-thunk";

export default function configureStore(initialState) {
    const cEnhancers =
        typeof window === "object" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
            ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
                // Extensions
            })
            : compose;

    const enhancers = cEnhancers(applyMiddleware(thunk));

    return createStore(rootReducer, initialState, enhancers);
}