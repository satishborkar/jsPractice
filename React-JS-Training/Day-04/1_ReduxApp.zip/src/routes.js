import React from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import Loadable from "react-loadable";

import HomeComponent from "./components/home/HomeComponent";
import CounterComponent from "./components/counter/CounterComponent";
import ProductsPage from "./containers/products/ProductsPage";
import ManageProductPage from "./containers/products/ManageProductPage";
const AboutComponent = Loadable({
    loader: () => import("./components/about/AboutComponent"),
    loading: () => <div>Loading.....</div>
})

export default (
    <Switch>
        <Route exact path="/" component={HomeComponent} />
        <Route path="/about" component={AboutComponent} />
        <Route path="/counter" component={CounterComponent} />
        <Route path="/products" component={ProductsPage} />
        <Route path="/product/:id" component={ManageProductPage} />
        <Route path="/product" component={ManageProductPage} />
    </Switch>
);