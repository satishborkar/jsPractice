export default {
    count: 0,
    products: []
}