import React from "react";

const HomeComponent = () => (
    <div>
        <h1>Home Component</h1>
        <p>This is a simple React Redux Application</p>
    </div>
);

export default HomeComponent;