import React from "react";
import HeaderComponent from "./common/HeaderComponent";

class Root extends React.Component {
    render() {
        return <div className="container-fluid">
            <HeaderComponent/>
        </div>;
    }
}

export default Root;