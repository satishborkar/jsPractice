import React from 'react';
import Counter from '../../containers/Counter';

const CounterComponent = () => {
    return (
        <div>
            <Counter></Counter>
        </div>
    );
}

export default CounterComponent;