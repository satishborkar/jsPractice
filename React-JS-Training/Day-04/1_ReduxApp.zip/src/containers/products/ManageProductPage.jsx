import React, { Component } from 'react';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import PropTypes from "prop-types";

import * as productActions from "../../actions/productActions";
import ProductForm from '../../components/products/ProductForm';

class ManageProductPage extends Component {
    constructor(props, context) {
        super(props);
        this.state = {
            product: this.props.product
        };
        this.saveProduct = this.saveProduct.bind(this);
        this.updateProductState = this.updateProductState.bind(this);
    }

    updateProductState(e) {
        const field = e.target.name;
        let product = this.state.product;
        product[field] = e.target.value;
        this.setState({ product: product });
    }

    saveProduct(e) {
        e.preventDefault();
        if (this.state.product.id)
            this.props.actions.updateProduct(this.state.product);
        else
            this.props.actions.saveProduct(this.state.product);
        this.context.router.history.push("/products");
    }

    render() {
        return (
            <div>
                <ProductForm
                    pageText={this.props.ptext}
                    product={this.state.product}
                    onChange={this.updateProductState}
                    onSave={this.saveProduct} />
            </div>
        );
    }
}

ManageProductPage.contextTypes = {
    router: PropTypes.shape({
        history: PropTypes.object.isRequired
    })
}

function getProductById(products, id) {
    const product = products.filter(product => product.id == id);
    if (product) return product[0];
    return null;
}

function mapStateToProps(state, ownProps) {
    const productId = ownProps.match.params.id;

    let product = {
        id: "",
        name: "",
        description: "",
        status: ""
    };

    if (productId && state.productReducer.length > 0) {
        product = getProductById(state.productReducer, productId);
    }

    var ptext = product.id == "" ? "Create Product" : "Edit Product";

    // return {
    //     product: product,
    //     ptext: ptext
    // };

    return { product, ptext };
}

function mapDispatchToProps(dispatch) {
    var obj = {
        actions: bindActionCreators(productActions, dispatch)
    }
    return obj;
}

export default connect(mapStateToProps, mapDispatchToProps)(ManageProductPage);