import React, { Component } from 'react';
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

import { withRouter } from "react-router-dom";

import * as productActions from "../../actions/productActions";
import ProductList from '../../components/products/ProductList';

class ProductsPage extends Component {
    constructor(props) {
        super(props);
        this.loadClick = this.loadClick.bind(this);
        this.deleteClick = this.deleteClick.bind(this);
    }

    loadClick(e) {
        // this.props.actions.loadProducts();
    }

    deleteClick(p, e) {
        e.preventDefault();
        this.props.actions.deleteProduct(p);
    }

    componentDidMount() {
        this.props.actions.loadProducts();
    }

    render() {
        return (
            <div>
                <h1>Products Page</h1>
                <RedirectButton />
                {/* <button className="btn btn-primary" onClick={this.loadClick}>Load</button> */}
                <ProductList products={this.props.products} onDelete={this.deleteClick} />
            </div>
        )
    }
}

const RedirectButton = withRouter(({ history }) => (
    <button type="button" className="btn btn-primary"
        onClick={() => {
            history.push("/product");
        }}>Add Product</button>
));

function mapStateToProps(state, ownProps) {
    return {
        products: state.productReducer
    }
}

function mapDispatchToProps(dispatch) {
    var obj = {
        actions: bindActionCreators(productActions, dispatch)
    }
    return obj;
}

export default connect(mapStateToProps, mapDispatchToProps)(ProductsPage);