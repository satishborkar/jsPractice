import React from "react";

const AboutComponent = () => (
    <div>
        <h1>About Component</h1>
        <p>This is a simple React Redux Application</p>
    </div>
);

export default AboutComponent;