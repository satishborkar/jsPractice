// Case 1
// export default function square(x) {
//     return x * x;
// }

// Case 2
// export function square(x) {
//     return x * x;
// }

// export function check() {
//     console.log("Check Called...");
// }

// Case 3
export default function square(x) {
    return x * x;
}

export function check() {
    console.log("Check Called...");
}