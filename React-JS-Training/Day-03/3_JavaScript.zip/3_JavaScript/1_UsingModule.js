//Case 1
// import sqr from './MyModule';
// console.log(sqr(2));

//Case 2

// import {square, check} from './MyModule';
// console.log(square(2));
// check();

// import { square } from './MyModule';
// console.log(square(2));

// import * as lib from './MyModule';
// console.log(lib.square(2));
// lib.check();

// Case 3
import square, { check } from './MyModule';
console.log(square(2));
check();
