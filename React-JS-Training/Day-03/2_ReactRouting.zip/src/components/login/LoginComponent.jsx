import React from "react";
import "babel-polyfill";
import { Redirect } from "react-router-dom";

import { Button, FormGroup, FormControl, ControlLabel } from "react-bootstrap";

class LoginComponent extends React.Component {
    constructor() {
        super();
        this.state = {
            redirectToReferrer: false,
            username: "",
            password: ""
        };
        this.handleChange = this.handleChange.bind(this);
        this.validateForm = this.validateForm.bind(this);
        this.login = this.login.bind(this);
    }

    validateForm() {
        return this.state.username.length > 0 && this.state.password.length > 0;
    }

    handleChange(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    login(e) {
        e.preventDefault();
        authenticator.authenticate(() => {
            this.setState({ redirectToReferrer: authenticator.isAuthenticated })
        }, this.state.username, this.state.password);
    }

    render() {
        const { from } = this.props.location.state || { from: { pathname: "/" } };
        const { redirectToReferrer } = this.state;

        if (redirectToReferrer) {
            return <Redirect to={from} />;
        }

        return (
            <div>
                <form onSubmit={this.login}>
                    <FormGroup controlId="username" bsSize="large">
                        <ControlLabel>Username</ControlLabel>
                        <FormControl
                            autoFocus
                            type="username"
                            value={this.state.username}
                            onChange={this.handleChange}
                        />
                    </FormGroup>
                    <FormGroup controlId="password" bsSize="large">
                        <ControlLabel>Password</ControlLabel>
                        <FormControl
                            value={this.state.password}
                            onChange={this.handleChange}
                            type="password"
                        />
                    </FormGroup>
                    <Button
                        block
                        bsSize="large"
                        disabled={!this.validateForm()}
                        type="submit">
                        Login
                    </Button>
                </form>
            </div>
        );
    }
}

export const authenticator = {
    isAuthenticated: false,
    authenticate(cb, uname, pwd) {
        var data = `username=${uname}&password=${pwd}`;

        let fData = {
            method: 'POST',
            headers: {
                "Content-type": "application/x-www-form-urlencoded"
            },
            body: data
        };

        fetch('http://localhost:8000/api/authenticate', fData).then((res) => res.json())
            .then((data) => {
                this.isAuthenticated = data.success;
                window.sessionStorage.setItem("tk", data.token);
                cb();
            })
    }
}

export default LoginComponent;