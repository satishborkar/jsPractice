import React from "react";
import { Switch, Route, Redirect } from "react-router-dom";

import HomeComponent from "./components/home/HomeComponent";

// import AboutComponent from "./components/about/AboutComponent";
// import ProductsComponent from "./components/products/ProductsComponent";

import Loadable from "react-loadable";

const AboutComponent = Loadable({
    loader: () => import("./components/about/AboutComponent"),
    loading: () => <div>Loading.....</div>
})

import asyncLoader from "./components/AsyncComponentLoader";
import LoginComponent, { authenticator } from "./components/login/LoginComponent";

const ProductsComponent = asyncLoader(function () {
    return import("./components/products/ProductsComponent").then(function (
        module
    ) {
        return module.default;
    });
});


const AdminComponent = ({ match }) => {
    return (
        <div>
            <h2>Welcome Admin...</h2>
        </div>
    );
};

const PrivateRoute = ({ component: Component, ...rest }) => {
    return (
        <Route {...rest} render={props => authenticator.isAuthenticated === true ? (
            <Component {...props} />
        ) : (
                <Redirect to={{ pathname: "/login", state: { from: props.location } }} />
            )} />
    );
};

export default (
    <Switch>
        <Route exact path="/" component={HomeComponent} />
        <Route path="/about" component={AboutComponent} />
        <Route path="/products" component={ProductsComponent} />
        <PrivateRoute path="/admin" component={AdminComponent} />
        <Route path="/login" component={LoginComponent} />
    </Switch>
);