import React from "react";

class HelloComponent extends React.Component{
    render(){
        return <h2>This is Hello Component</h2>;
    }
}

export default HelloComponent;