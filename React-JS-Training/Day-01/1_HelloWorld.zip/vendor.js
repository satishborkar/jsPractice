import React from 'react';
import ReactDOM from 'react-dom';

// Other Vendor Files, like jquery, bootstrap