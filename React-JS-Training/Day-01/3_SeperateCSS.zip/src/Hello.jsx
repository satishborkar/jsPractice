import React from "react";

class Hello extends React.Component {
    render() {
        return <h1 className="text-danger">Hello World!</h1>;
    }
}

export default Hello;