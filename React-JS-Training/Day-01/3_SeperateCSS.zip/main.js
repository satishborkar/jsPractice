import React from 'react';
import ReactDOM from 'react-dom';

import Hello from './src/Hello.jsx'; 

ReactDOM.render(<Hello />, document.getElementById("container"));