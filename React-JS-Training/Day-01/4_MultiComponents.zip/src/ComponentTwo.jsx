import React from "react";

class ComponentTwo extends React.Component {
    render() {
        return <h1 className="text-success">Hi World!</h1>;
    }
}

export default ComponentTwo;