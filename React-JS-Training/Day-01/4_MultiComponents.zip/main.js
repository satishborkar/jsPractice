import React from 'react';
import ReactDOM from 'react-dom';

import ComponentOne from './src/ComponentOne';
import ComponentTwo from './src/ComponentTwo'; 
 
ReactDOM.render(<ComponentOne />, document.getElementById("container1"));
ReactDOM.render(<ComponentTwo />, document.getElementById("container2"));
