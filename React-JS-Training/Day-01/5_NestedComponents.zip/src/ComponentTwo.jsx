import React from "react";

class ComponentTwo extends React.Component {
    render() {
        return <h2 className="text-success">Hello from Component Two!</h2>;
    }
}

export default ComponentTwo;