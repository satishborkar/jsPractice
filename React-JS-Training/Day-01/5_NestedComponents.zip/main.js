import React from 'react';
import ReactDOM from 'react-dom';

import Root from './src/Root'; 

ReactDOM.render(<Root />, document.getElementById("container"));