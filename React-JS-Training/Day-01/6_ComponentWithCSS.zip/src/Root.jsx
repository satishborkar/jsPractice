import React from "react";

import ComponentOne from './CompOne/ComponentOne';
import ComponentTwo from './CompTwo/ComponentTwo';

class Root extends React.Component {
    render() {
        return <div>
            <h1 className="text-danger">Root</h1>
            <ComponentOne />
            <ComponentTwo />
        </div>;
    }
}

export default Root;