// import React from "react";

// class ComponentOne extends React.Component {
//     render() {
//         const test = {
//             margin: '1em',
//             paddingLeft: 0,
//             border: '2px solid blue'
//         };
//         return <h2 style={test} className="text-info">Hello from Component One!</h2>;
//     }
// }

// export default ComponentOne;


import React from "react";
import './ComponentOne.css';

class ComponentOne extends React.Component {
    render() {
        return <h2 className="text-info card1">Hello from Component One!</h2>;
    }
}

export default ComponentOne;