import React from "react";
import styles from  './ComponentOne.css';

class ComponentOne extends React.Component {
    render() {
        return <h2 className={`${styles.card} text-info`}>Hello from Component One!</h2>;
    }
}

export default ComponentOne;