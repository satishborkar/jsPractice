import React from "react";
import styles from './ComponentTwo.css';

class ComponentTwo extends React.Component {
    render() {
        return <h2 className={`${styles.card} text-success`}>Hello from Component Two!</h2>;
    }
}

export default ComponentTwo;